print('Hola from EC2')
